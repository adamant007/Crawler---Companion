import { StrictMode, useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type Stat = { value: string; mod: string; enhanced: boolean };
type Character = {
  name: string; race: string; pronouns: string; level: string; crawlerNumber: string; className: string; floor: string;
  stats: Record<string, Stat>;
  skills: { name: string; rank: string; statMod: string; checkType: string; notes: string; trained: boolean }[];
  hotlist: string[];
  notes: string;
};

const statNames = ["Strength","Intelligence","Constitution","Dexterity","Charisma"];
const emptyCharacter = (): Character => ({
  name:"", race:"", pronouns:"", level:"", crawlerNumber:"", className:"", floor:"",
  stats:Object.fromEntries(statNames.map(s=>[s,{value:"",mod:"",enhanced:false}])),
  skills:Array.from({length:10},()=>({name:"",rank:"",statMod:"",checkType:"",notes:"",trained:false})),
  hotlist:Array.from({length:10},()=>""), notes:""
});

function load(): Character {
  try { return {...emptyCharacter(), ...JSON.parse(localStorage.getItem("crawler-character") || "null")}; }
  catch { return emptyCharacter(); }
}

const tabs = ["Character","Inventory","Equipment","Progression","Dice","Party","GM Tools"];

function App() {
  const [tab,setTab] = useState("Character");
  const [c,setC] = useState<Character>(load);
  const [roll,setRoll] = useState<number|null>(null);
  const [saved,setSaved] = useState(false);

  useEffect(()=>{ localStorage.setItem("crawler-character",JSON.stringify(c)); setSaved(true); const t=setTimeout(()=>setSaved(false),700); return()=>clearTimeout(t)},[c]);

  const floor3 = Number(c.floor) >= 3;
  const set = (k:keyof Character,v:string) => setC(x=>({...x,[k]:v}));
  const setStat=(s:string,k:keyof Stat,v:string|boolean)=>setC(x=>({...x,stats:{...x.stats,[s]:{...x.stats[s],[k]:v}}}));
  const updateSkill=(i:number,k:string,v:string|boolean)=>setC(x=>({...x,skills:x.skills.map((r,j)=>j===i?{...r,[k]:v}:r)}));

  const content = useMemo(()=>{
    if(tab==="Character") return (
      <>
        <section className="card hero">
          <div><span className="eyebrow">CHARACTER CREATOR</span><h2>Build your crawler</h2><p>Save your character locally and keep the sheet ready at the table.</p></div>
          <span className={"save "+(saved?"active":"")}>{saved?"SAVED":"AUTOSAVE"}</span>
        </section>
        <div className="two">
          <section className="card">
            <h3>Identity</h3>
            <div className="fields">
              {(["name","race","pronouns","level","crawlerNumber","className","floor"] as const).map(k=>
                <label key={k}><span>{k==="crawlerNumber"?"Crawler Number":k==="className"?"Class":k[0].toUpperCase()+k.slice(1)}</span>
                  <input value={c[k]} onChange={e=>set(k,e.target.value)} />
                </label>)}
            </div>
            <div className={"floor3 "+(floor3?"ready":"")}><strong>{floor3?"Floor 3 transition available":"Floor 3 transition"}</strong><span>{floor3?"Race and Class can be selected/changed here.":"Enter Floor 3 when your crawler reaches the transition."}</span></div>
          </section>
          <section className="card">
            <h3>Stats</h3>
            <div className="stats">{statNames.map(s=><div className="stat" key={s}><b>{s}</b><input placeholder="Value" value={c.stats[s].value} onChange={e=>setStat(s,"value",e.target.value)}/><input placeholder="Mod" value={c.stats[s].mod} onChange={e=>setStat(s,"mod",e.target.value)}/><label className="check"><input type="checkbox" checked={c.stats[s].enhanced} onChange={e=>setStat(s,"enhanced",e.target.checked)}/> Enhanced</label></div>)}</div>
          </section>
        </div>
        <section className="card">
          <h3>Skills</h3><div className="skill-head"><span>Name</span><span>Rank</span><span>Stat & Mod</span><span>Check Type</span><span>Notes & Upgrades</span><span>✓</span></div>
          {c.skills.map((r,i)=><div className="skill-row" key={i}><input value={r.name} onChange={e=>updateSkill(i,"name",e.target.value)}/><input value={r.rank} onChange={e=>updateSkill(i,"rank",e.target.value)}/><input value={r.statMod} onChange={e=>updateSkill(i,"statMod",e.target.value)}/><input value={r.checkType} onChange={e=>updateSkill(i,"checkType",e.target.value)}/><input value={r.notes} onChange={e=>updateSkill(i,"notes",e.target.value)}/><input type="checkbox" checked={r.trained} onChange={e=>updateSkill(i,"trained",e.target.checked)}/></div>)}
        </section>
      </>
    );
    if(tab==="Dice") return <section className="card center"><span className="eyebrow">DICE</span><h2>Table dice</h2><p>Quick d20 roller for now. More dice options can be added next.</p><button onClick={()=>setRoll(Math.floor(Math.random()*20)+1)}>Roll d20</button>{roll!==null&&<div className="roll">{roll}</div>}</section>;
    if(tab==="Progression") return <section className="card"><span className="eyebrow">PROGRESSION</span><h2>Character progression</h2><p>Track floor, level, skills and milestones here. The Floor 3 Race/Class transition is already represented on the Character tab.</p></section>;
    if(tab==="Inventory") return <section className="card"><span className="eyebrow">INVENTORY</span><h2>Inventory</h2><p>Inventory management is next: items, quantities, notes and hotlist.</p></section>;
    if(tab==="Equipment") return <section className="card"><span className="eyebrow">EQUIPMENT</span><h2>Equipment</h2><p>Gear slots and equipment tracking are ready for the next build phase.</p></section>;
    if(tab==="Party") return <section className="card"><span className="eyebrow">PARTY</span><h2>Party</h2><p>Party roster and shared table tools will live here.</p></section>;
    return <section className="card"><span className="eyebrow">GM TOOLS</span><h2>GM command center</h2><p>Loot generator and future GM utilities will live here.</p></section>;
  },[tab,c,saved,roll]);

  return <main>
    <header><div><span className="eyebrow">CRAWLER COMPANION</span><h1>Character Dashboard</h1><p>Your table-side command center.</p></div><span className="badge">WEB EDITION</span></header>
    <nav>{tabs.map(t=><button key={t} className={tab===t?"selected":""} onClick={()=>setTab(t)}>{t}</button>)}</nav>
    {content}
    <footer>Prototype build · DCC-specific rules/content remain gated until licensing is secured.</footer>
  </main>;
}
createRoot(document.getElementById("root")!).render(<StrictMode><App/></StrictMode>);
