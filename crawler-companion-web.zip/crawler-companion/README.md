# Crawler Companion

A production-ready React/Vite starting point for the Crawler Companion web app.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
```

The project is designed to deploy cleanly to Vercel. Vercel provides automatic HTTPS/CDN delivery and can import a GitHub repository with framework defaults. See the official Vercel React/Vite template and deployment documentation.

## Current foundation

- Responsive tabbed dashboard
- Character creator
- Local autosave
- Character stats and skills
- Explicit Floor 3 Race/Class transition state
- Dice tab with d20 roller
- Placeholder sections for Inventory, Equipment, Progression, Party and GM Tools

DCC-specific copyrighted rules/text/art should only be added when appropriate licensing/permission is in place.
